from .utils import *
import faiss

class KVCache(object):
    def __init__(self, path, init=False, sync_updates=300):
        self.path = path
        if init: self.init(model=init)
        else: self.load()
        self.sync_updates = sync_updates; self.sync = 0

    def load(self):
        try:
            self.config = LoadJson(pjoin(self.path, "config.json"))
            self.tokenizer, self.model = load_model(self.config['model'])
            self.index = faiss.read_index(pjoin(self.path, "index.faiss"))
            self.keys = LoadJson(pjoin(self.path, "keys.jsonl"), backend="jsonl")
            self.values = LoadJson(pjoin(self.path, "values.jsonl"), backend="jsonl")
        except:
            self.init()
    
    def save(self):
        SaveJson(self.config, pjoin(self.path, "config.json"), indent=4)
        faiss.write_index(self.index, pjoin(self.path, "index.faiss"))
        SaveJson(self.keys, pjoin(self.path, "keys.jsonl"), backend="jsonl")
        SaveJson(self.values, pjoin(self.path, "values.jsonl"), backend="jsonl")
    
    def init(self, model):
        self.config = {"model": model, "dim": 384}
        self.tokenizer, self.model = load_model(self.config['model'], download=True)
        self.index = faiss.IndexFlatL2(self.config['dim'])
        self.keys = list()
        self.values = list()
        self.save()
    
    def query(self, key):
        embed = faiss.normalize_L2(embedding(key, self.tokenizer, self.model))
        distances, indices = self.index.search(embed, 1)
        d, ind = distances[0][0], indices[0][0]
        key, value = self.keys[ind], self.values[ind]
        if d < 0.1:
            return key, value
        else:
            return None, None
        
    def update(self, key, value):
        self.keys.append(key); self.values.append(value)
        embed = faiss.normalize_L2(embedding(key, self.tokenizer, self.model))
        self.index.add(embed); self.sync += 1
        if self.sync >= self.sync_updates:
            self.sync = 0; self.save()