from .utils import *

class LMSimulator(object):
    def __init__(self, path, init=False, sync_updates=300):
        self.path = path
        if init: self.init(model=init)
        else: self.load()
        self.sync_updates = sync_updates; self.sync = 0

    def load(self):
        try:
            self.config = LoadJson(pjoin(self.path, "config.json"))
            self.tokenizer, self.model = load_model(self.config['model_path'])
            self.dataset = LoadJson(self.config["dataset_path"], backend="jsonl")
        except:
            self.init()
    
    def save(self):
        SaveJson(self.config, pjoin(self.path, "config.json"), indent=4)
        self.tokenizer.save_pretrained(self.config["model_path"])
        self.model.save_pretrained(self.config["model_path"])
        SaveJson(self.dataset, self.config["dataset_path"], backend="jsonl")
    
    def init(self, model):
        self.config = {"model": model, "dim": 384}
        self.config["model_path"] = pjoin(self.path,"ckpts")
        self.config["dataset_path"] = pjoin(self.path, "dataset")
        CreateFolder(self.config["model_path"])
        CreateFolder(self.config["dataset_path"])
        self.tokenizer, self.model = load_model(self.config['model'], download=True)
        self.dataset = list()
        self.save()
    
    def update(self, key, value):
        self.dataset.append((key, value)); self.sync += 1
        if self.sync >= self.sync_updates:
            self.sync = 0; self.train(); self.save()

    def encode(self, example):
        return self.tokenizer(example['source'], truncation=True, padding='max_length')
    
    def query(self, key):
        return inference(key, self.tokenizer, self.model)
    
    def train(self, cont=False):
        if not cont:
            self.tokenizer, self.model = load_model(self.config['model'])
        
        encoded_dataset = self.dataset.map(self.encode, batched=True)
        dataset_split = encoded_dataset.train_test_split(test_size=0.1)
        train_dataset, valid_dataset = dataset_split['train'], dataset_split['test']
        data_collator = DataCollatorForSeq2Seq(tokenizer=self.tokenizer, model=self.model)
        
        training_args = Seq2SeqTrainingArguments(
            output_dir=self.path,
            evaluation_strategy="epoch",
            learning_rate=2e-5,
            per_device_train_batch_size=16,
            per_device_eval_batch_size=4,
            weight_decay=0.01,
            save_total_limit=3,
            num_train_epochs=2,
            fp16=True,
            predict_with_generate=True,
        )

        trainer = Seq2SeqTrainer(
            tokenizer=self.tokenizer,
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=valid_dataset,
            data_collator=data_collator,
        )
        
        trainer.train()
            
class CLSSimulator(LMSimulator):
    def __init__(self, path, num_classes, init=False, sync_updates=300):
        self.path = path
        if init: self.init(model=init)
        else: self.load()
        self.sync_updates = sync_updates; self.sync = 0
        self.num_classes = num_classes
    
    def init(self, model):
        self.config = {"model": model, "dim": 384}
        self.config["model_path"] = pjoin(self.path,"ckpts")
        self.config["dataset_path"] = pjoin(self.path, "dataset")
        CreateFolder(self.config["model_path"])
        CreateFolder(self.config["dataset_path"])
        self.tokenizer, self.model = load_model(self.config['model'], download=True, num_labels=self.num_classes)
        self.dataset = list()
        self.save()
        
    def encode(self, example):
        return self.tokenizer(example['source'], truncation=True, padding='max_length')
    
    def query(self, key):
        return embedding(key, self.tokenizer, self.model)
    
    def train(self, cont=False):
        if not cont:
            self.tokenizer, self.model = load_model(self.config['model'])
        
        encoded_dataset = self.dataset.map(self.encode, batched=True)
        dataset_split = encoded_dataset.train_test_split(test_size=0.1)
        train_dataset, valid_dataset = dataset_split['train'], dataset_split['test']
        data_collator = DefaultDataCollator(tokenizer=self.tokenizer, model=self.model)
        
        training_args = TrainingArguments(
            output_dir=self.path,
            evaluation_strategy="epoch",
            learning_rate=2e-5,
            per_device_train_batch_size=16,
            per_device_eval_batch_size=4,
            weight_decay=0.01,
            save_total_limit=3,
            num_train_epochs=2,
            fp16=True,
        )

        trainer = Trainer(
            tokenizer=self.tokenizer,
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=valid_dataset,
            data_collator=data_collator,
        )
        
        trainer.train()