from .default import *
from langchain.prompts import PromptTemplate

class LLMQueryPromptTemplate(PromptTemplate):
    def format(self, data) -> str:
        return self.template.format(
            task_desc = data.task_desc,
            examples_desc = add_indent(parse_examples(data.examples)),
            outputs_desc = "Instance #0:\n" + add_indent("\n".join([f"{o}=?" for o in data.outputs])) + "\n...\n",
            instance = "{instance}",
        )

LLMQUERY_PROMPT_TEMPALTE = LLMQueryPromptTemplate.from_template(
    "{task_desc}\n"
    "Examples:\n"
    "{examples_desc}\n"
    "Now consider the following instance(s):\n"
    "{instance}\n"
    "Please respond with the answer only. Please do not output any other responses or any explanations.\n"
    "Your respond should strictly align with the format of `Output:` in the above examples, including the punctuations. It should be in the following format for each instance:\n"
    "{outputs_desc}\n"
)

@LinguaManga.register
class LLMQueryModule(Module):
    __type__: str = 'module-llmquery'
    def __init__(self, name, *args, **kwargs):
        super().__init__(name=name, *args, **kwargs); self.__type__ = self.__type__
        if self.task_desc is None: self.task_desc = ""
        if self.inputs_desc is None: self.inputs_desc = dict()
        if self.outputs_desc is None: self.outputs_desc = dict()
        if self.tools_desc is None: self.tools_desc = dict()
        self.inputs = list(self.inputs_desc.keys())
        self.outputs = list(self.outputs_desc.keys())

    def __compile__(self):
        prompt = LLMQUERY_PROMPT_TEMPALTE.format(data=self)
        build_example_code = "inputs, outputs = dict(), dict()\n"
        for key in self.inputs:
            build_example_code += f"{parameterize(key, param='inputs')} = {key}\n"
        for key in self.outputs:
            build_example_code += f"{parameterize(key, param='outputs')} = '?'\n"
        code = (
            f"def {self.api()}:\n"+ 
            add_indent(f"'''")+"\n"+
            add_indent(prompt)+"\n"+
            add_indent(f"'''")+"\n"+
            add_indent(build_example_code)+"\n"+
            add_indent(f"prompt = {repr(prompt)}")+"\n"+
            add_indent(f"return LLMQueryExec(prompt, [inputs])[0]")+"\n"
        )
        
        batching_code = (
            f"def {self.batch_api()}:\n"+ 
            add_indent(f"prompt = {repr(prompt)}")+"\n"+
            add_indent(f"return LLMQueryExec(prompt, instances)")+"\n"
        )
        
        caching_code = (
            f"{self.name}_cache = KVCache(path='./cache/')"+"\n"+
            f"def {self.catch_api()}:\n"+
            add_indent(build_example_code)+"\n"+
            add_indent(f"key = '|'.join(['function={self.name}'] + "+"[f'{k}={v}' for k,v in inputs.items()])")+"\n"+
            add_indent(f"value, d = {self.name}_cache.query(key)")+"\n"+
            add_indent(f"if value is None:")+"\n"+
            add_indent(f"    value = {self.name}(**inputs)", 2)+"\n"+
            add_indent(f"    {self.name}_cache.update(key, value)", 2)+"\n"+
            add_indent(f"return value")
        )
        return Cell(code="\n\n".join([code,batching_code,caching_code]))