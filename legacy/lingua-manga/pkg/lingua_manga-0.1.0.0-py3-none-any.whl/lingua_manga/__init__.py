from .utils import *
from .modules import Module, ManualModule, LLMGCModule, LLMQueryModule
from .cacher import KVCache
from .simulator import LMSimulator, CLSSimulator

def CreateProject(name, clear=False):
    projects = GetConfig("paths")['projects_path']
    root = pjoin(projects, name); CreateFolder(root)
    data = pjoin(root, "data"); CreateFolder(data)
    cache = pjoin(root, "cache"); ClearFolder(cache) if clear else CreateFolder(cache)
    workspace = pjoin(root, "workspace"); ClearFolder(workspace) if clear else CreateFolder(workspace)
    modules = pjoin(root, "modules"); ClearFolder(modules) if clear else CreateFolder(modules)
    simuls = pjoin(root, "simuls"); ClearFolder(simuls) if clear else CreateFolder(simuls)
    KVCache(path=cache, init="sentence-transformers/all-MiniLM-L12-v2")
    
def AddModule(project, module):
    projects = GetConfig("paths")['projects_path']
    root = pjoin(projects, project); CreateFolder(root)
    modules = pjoin(root, "modules"); CreateFolder(modules)
    module_path = pjoin(modules, module.name); CreateFolder(module_path)
    module.save(pjoin(module_path, "config.json"), indent=4)

def CompileProject(project):
    projects = GetConfig("paths")['projects_path']
    root = pjoin(projects, project); CreateFolder(root)
    modules = pjoin(root, "modules"); CreateFolder(modules)
    executables = []
    executables.append(
        Cell(code = "from lingua_manga import *")
    )
    for module_name in ListFolders(modules, ordered=True):
        module = LinguaManga.load(pjoin(modules, module_name, "config.json"))
        module.compile(); module.save(pjoin(modules, module_name), indent=4)
        executables.append(module.__executable__)
    compiled = pjoin(root, AsFormat(project, "py"))
    with open(compiled, "w") as f:
        f.write("# %%\n" + ("# %%\n".join([e.code+"\n\n" for e in executables])))
        f.write("# %%\n")