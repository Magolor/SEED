from pyheaven import *
from typing import *

from dataclasses import dataclass
from os.path import expanduser

import io
import contextlib
import IPython.terminal.embed as embed

import openai

import transformers
from transformers import AutoTokenizer, AutoModel
from transformers import Trainer, TrainingArguments, Seq2SeqTrainer, Seq2SeqTrainingArguments
from transformers.data import DefaultDataCollator, DataCollatorForSeq2Seq

# lingua manga utils
LG_ROOT = pjoin(expanduser("~"), ".lingua-manga")
LG_CKPTS = pjoin(LG_ROOT, "ckpts")

def GetConfig(config):
    return LoadJson(pjoin(LG_ROOT, f"{config}.json"))

# string utils
import re
def add_indent(code, indent=1, tab=4):
    T = ((" "*tab if tab>=0 else "\t") if isinstance(tab, int) else tab)*indent
    return T + code.strip().replace("\n", "\n"+T)

def find_command(text):
    return re.findall(r'<[^<>]+>', text)

def parameterize(key, param="data"):
    return f"{param}['{key}']"

def parse_keys(data):
    return "\n".join([f"{k}: {v}" for k,v in data.items()]) if len(data)>0 else "None"

def parse_inputs(inputs):
    return f"Input:\n" + add_indent("\n".join([f"{k}={repr(v)}" for k,v in inputs.items()]) if len(inputs)>0 else "None")

def parse_outputs(outputs):
    return f"Output:\n" + add_indent("\n".join([f"{k}={repr(v)}" for k,v in outputs.items()]) if len(outputs)>0 else "None")

def parse_example(inputs, outputs, i=None):
    return "\n".join([("Example:" if i is None else f"Example #{i}:"),add_indent(parse_inputs(inputs)),add_indent(parse_outputs(outputs))])

def parse_examples(examples):
    return "\n".join([parse_example(inputs, outputs, i) for i, (inputs, outputs) in enumerate(examples)]) if len(examples)>0 else "None"

def parse_instance(inputs, i=None):
    return "\n".join([("Instance:" if i is None else f"Instance #{i}:"),add_indent(parse_inputs(inputs))])

def parse_instances(examples):
    return "\n".join([parse_instance(inputs, i) for i, (inputs, outputs) in enumerate(examples)]) if len(examples)>0 else "None"

# cache utils
def retrieve_cache(key):
    key = key.lower().strip()
    cache = LoadJson(pjoin(LG_ROOT, "cache.json"))
    if key in cache:
        return cache[key]
    return None

def update_cache(key, value, update=False):
    key = key.lower().strip()
    cache = LoadJson(pjoin(LG_ROOT, "cache.json"))
    if update or (key not in cache):
        cache[key] = value
    SaveJson(cache, pjoin(LG_ROOT, "cache.json"))

def clear_cache():
    SaveJson(dict(), pjoin(LG_ROOT, "cache.json"))

# file utils
def load_model(model_name, download=False, *args, **kwargs):
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name, local_files_only=True)
        model = AutoModel.from_pretrained(model_name, local_files_only=True)
    except:
        path = pjoin(LG_CKPTS, model_name)
        try:
            tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
            model = AutoModel.from_pretrained(path, local_files_only=True, *args, **kwargs)
        except:
            if download:
                tokenizer = AutoTokenizer.from_pretrained(model_name)
                model = AutoModel.from_pretrained(model_name)
                tokenizer.save_pretrained(path)
                model.save_pretrained(path)
                model = AutoModel.from_pretrained(path, local_files_only=True, *args, **kwargs)
            else:
                tokenizer, model = None, None
    return tokenizer, model

def embedding(x, tokenizer, model):
    inputs = tokenizer([x], max_length=1024, return_tensors="pt")
    output = model(**inputs)[0]
    return output

def inference(x, tokenizer, model):
    inputs = tokenizer([x], max_length=1024, return_tensors="pt")
    output_ids = model.generate(inputs["input_ids"], num_beams=3, min_length=0, max_length=512)
    output = tokenizer.batch_decode(output_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0]
    return output

def GetModel(path):
    try:
        tokenizer = AutoTokenizer.from_pretrained(path,local_files_only=True)
        model = AutoModel.from_pretrained(path,local_files_only=True)
    except:
        return None, None
    return tokenizer, model

def GetModelProfile(path):
    profile_path = pjoin(path, "profile.json")
    profile = LoadJson(profile_path) if ExistFile(profile_path) else dict()
    return profile

def GetModelDataset(path):
    dataset_path = pjoin(path, "dataset.jsonl")
    dataset = LoadJson(dataset_path, backend="jsonl") if ExistFile(dataset_path) else list()
    return dataset

def UpdateModelProfile(path, profile):
    profile_path = pjoin(path, "profile.json")
    SaveJson(profile, profile_path)

def UpdateModelDataset(path, data):
    dataset_path = pjoin(path, "dataset.jsonl")
    dataset = LoadJson(dataset_path, backend="jsonl") if ExistFile(dataset_path) else list()
    dataset.append(data); SaveJson(dataset, dataset_path, backend="jsonl")